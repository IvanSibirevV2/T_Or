﻿using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Linq;

namespace ClickerManDVA
{
    class Program
    {
        static void Main(string[] args)
        {


            /*
             
            List<System.Boolean> BoolS = new List<bool>() { true, !false, !false };
            System.Console.WriteLine(BoolS.Aggregate((a,b)=>a&&b).ToString());
            ;
            System.Console.Read();
            
            (new System.Klava())
                .VK_Q_Is(x => System.Console.WriteLine("true"), x => System.Console.WriteLine("false"))
                .Sleep()
                .VK_Q_Down()
                .Sleep()
                .VK_Q_Is(x => System.Console.WriteLine("true"), x => System.Console.WriteLine("false"))
                .Sleep()
                .VK_Q_Up()
                .VK_Q_Is(x => System.Console.WriteLine("true"), x => System.Console.WriteLine("false"))
            ;
            while (true)
            {
                System.Console.WriteLine("!!!!!!!!!!!!!!!");
                System.Threading.Thread.Sleep(1000);
            }
            */
        }
    }
}