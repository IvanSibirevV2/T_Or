﻿

















using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Linq;

namespace System
{
    public partial class Klava
    {
        public Klava A{get{this.VK_A.Down();this.Sleep();this.VK_A.Up(); return this;} }
        public Klava B{get{this.VK_B.Down();this.Sleep();this.VK_B.Up(); return this;} }
        public Klava C{get{this.VK_C.Down();this.Sleep();this.VK_C.Up(); return this;} }
        public Klava D{get{this.VK_D.Down();this.Sleep();this.VK_D.Up(); return this;} }
        public Klava E{get{this.VK_E.Down();this.Sleep();this.VK_E.Up(); return this;} }
        public Klava F{get{this.VK_F.Down();this.Sleep();this.VK_F.Up(); return this;} }
        public Klava G{get{this.VK_G.Down();this.Sleep();this.VK_G.Up(); return this;} }
        public Klava H{get{this.VK_H.Down();this.Sleep();this.VK_H.Up(); return this;} }
        public Klava I{get{this.VK_I.Down();this.Sleep();this.VK_I.Up(); return this;} }
        public Klava J{get{this.VK_J.Down();this.Sleep();this.VK_J.Up(); return this;} }
        public Klava K{get{this.VK_K.Down();this.Sleep();this.VK_K.Up(); return this;} }
        public Klava L{get{this.VK_L.Down();this.Sleep();this.VK_L.Up(); return this;} }
        public Klava M{get{this.VK_M.Down();this.Sleep();this.VK_M.Up(); return this;} }
        public Klava N{get{this.VK_N.Down();this.Sleep();this.VK_N.Up(); return this;} }
        public Klava O{get{this.VK_O.Down();this.Sleep();this.VK_O.Up(); return this;} }
        public Klava P{get{this.VK_P.Down();this.Sleep();this.VK_P.Up(); return this;} }
        public Klava Q{get{this.VK_Q.Down();this.Sleep();this.VK_Q.Up(); return this;} }
        public Klava R{get{this.VK_R.Down();this.Sleep();this.VK_R.Up(); return this;} }
        public Klava S{get{this.VK_S.Down();this.Sleep();this.VK_S.Up(); return this;} }
        public Klava T{get{this.VK_T.Down();this.Sleep();this.VK_T.Up(); return this;} }
        public Klava U{get{this.VK_U.Down();this.Sleep();this.VK_U.Up(); return this;} }
        public Klava V{get{this.VK_V.Down();this.Sleep();this.VK_V.Up(); return this;} }
        public Klava W{get{this.VK_W.Down();this.Sleep();this.VK_W.Up(); return this;} }
        public Klava X{get{this.VK_X.Down();this.Sleep();this.VK_X.Up(); return this;} }
        public Klava Y{get{this.VK_Y.Down();this.Sleep();this.VK_Y.Up(); return this;} }
        public Klava Z{get{this.VK_Z.Down();this.Sleep();this.VK_Z.Up(); return this;} }
        public Klava _0{get{this.VK__0.Down();this.Sleep();this.VK__0.Up(); return this;} }
        public Klava _1{get{this.VK__1.Down();this.Sleep();this.VK__1.Up(); return this;} }
        public Klava _2{get{this.VK__2.Down();this.Sleep();this.VK__2.Up(); return this;} }
        public Klava _3{get{this.VK__3.Down();this.Sleep();this.VK__3.Up(); return this;} }
        public Klava _4{get{this.VK__4.Down();this.Sleep();this.VK__4.Up(); return this;} }
        public Klava _5{get{this.VK__5.Down();this.Sleep();this.VK__5.Up(); return this;} }
        public Klava _6{get{this.VK__6.Down();this.Sleep();this.VK__6.Up(); return this;} }
        public Klava _7{get{this.VK__7.Down();this.Sleep();this.VK__7.Up(); return this;} }
        public Klava _8{get{this.VK__8.Down();this.Sleep();this.VK__8.Up(); return this;} }
        public Klava _9{get{this.VK__9.Down();this.Sleep();this.VK__9.Up(); return this;} }
        public Klava Slash{get{this.VK_Slash.Down();this.Sleep();this.VK_Slash.Up(); return this;} }
        public Klava Space{get{this.VK_Space.Down();this.Sleep();this.VK_Space.Up(); return this;} }
        public Klava Enter{get{this.VK_Enter.Down();this.Sleep();this.VK_Enter.Up(); return this;} }
        public Klava Mark{get{this.VK_Mark.Down();this.Sleep();this.VK_Mark.Up(); return this;} }
        public Klava Shift{get{this.VK_Shift.Down();this.Sleep();this.VK_Shift.Up(); return this;} }
        public Klava F1{get{this.VK_F1.Down();this.Sleep();this.VK_F1.Up(); return this;} }
        public Klava F2{get{this.VK_F2.Down();this.Sleep();this.VK_F2.Up(); return this;} }
        public Klava F3{get{this.VK_F3.Down();this.Sleep();this.VK_F3.Up(); return this;} }
        public Klava F4{get{this.VK_F4.Down();this.Sleep();this.VK_F4.Up(); return this;} }
        public Klava F5{get{this.VK_F5.Down();this.Sleep();this.VK_F5.Up(); return this;} }
        public Klava F6{get{this.VK_F6.Down();this.Sleep();this.VK_F6.Up(); return this;} }
        public Klava F7{get{this.VK_F7.Down();this.Sleep();this.VK_F7.Up(); return this;} }
        public Klava F8{get{this.VK_F8.Down();this.Sleep();this.VK_F8.Up(); return this;} }
        public Klava F9{get{this.VK_F9.Down();this.Sleep();this.VK_F9.Up(); return this;} }
        public Klava F10{get{this.VK_F10.Down();this.Sleep();this.VK_F10.Up(); return this;} }
        public Klava F11{get{this.VK_F11.Down();this.Sleep();this.VK_F11.Up(); return this;} }
        public Klava F12{get{this.VK_F12.Down();this.Sleep();this.VK_F12.Up(); return this;} }
        public Klava BACKSPACE{get{this.VK_BACKSPACE.Down();this.Sleep();this.VK_BACKSPACE.Up(); return this;} }
        public Klava TAB{get{this.VK_TAB.Down();this.Sleep();this.VK_TAB.Up(); return this;} }
        public Klava CTRL{get{this.VK_CTRL.Down();this.Sleep();this.VK_CTRL.Up(); return this;} }
        public Klava ALT{get{this.VK_ALT.Down();this.Sleep();this.VK_ALT.Up(); return this;} }
        public Klava PAUSE{get{this.VK_PAUSE.Down();this.Sleep();this.VK_PAUSE.Up(); return this;} }
        public Klava CAPSLOCK{get{this.VK_CAPSLOCK.Down();this.Sleep();this.VK_CAPSLOCK.Up(); return this;} }
        public Klava ESCAPE{get{this.VK_ESCAPE.Down();this.Sleep();this.VK_ESCAPE.Up(); return this;} }
        public Klava PAGEUP{get{this.VK_PAGEUP.Down();this.Sleep();this.VK_PAGEUP.Up(); return this;} }
        public Klava PAGEDOWN{get{this.VK_PAGEDOWN.Down();this.Sleep();this.VK_PAGEDOWN.Up(); return this;} }
        public Klava END{get{this.VK_END.Down();this.Sleep();this.VK_END.Up(); return this;} }
        public Klava HOME{get{this.VK_HOME.Down();this.Sleep();this.VK_HOME.Up(); return this;} }
        public Klava LEFT{get{this.VK_LEFT.Down();this.Sleep();this.VK_LEFT.Up(); return this;} }
        public Klava UP{get{this.VK_UP.Down();this.Sleep();this.VK_UP.Up(); return this;} }
        public Klava RIGHT{get{this.VK_RIGHT.Down();this.Sleep();this.VK_RIGHT.Up(); return this;} }
        public Klava DOWN{get{this.VK_DOWN.Down();this.Sleep();this.VK_DOWN.Up(); return this;} }
        public Klava INSERT{get{this.VK_INSERT.Down();this.Sleep();this.VK_INSERT.Up(); return this;} }
        public Klava DELETE{get{this.VK_DELETE.Down();this.Sleep();this.VK_DELETE.Up(); return this;} }
        public Klava LWIN{get{this.VK_LWIN.Down();this.Sleep();this.VK_LWIN.Up(); return this;} }
        public Klava RWIN{get{this.VK_RWIN.Down();this.Sleep();this.VK_RWIN.Up(); return this;} }
        public Klava NumZero{get{this.VK_NumZero.Down();this.Sleep();this.VK_NumZero.Up(); return this;} }
        public Klava NumOne{get{this.VK_NumOne.Down();this.Sleep();this.VK_NumOne.Up(); return this;} }
        public Klava NumTwo{get{this.VK_NumTwo.Down();this.Sleep();this.VK_NumTwo.Up(); return this;} }
        public Klava NumThree{get{this.VK_NumThree.Down();this.Sleep();this.VK_NumThree.Up(); return this;} }
        public Klava NumFor{get{this.VK_NumFor.Down();this.Sleep();this.VK_NumFor.Up(); return this;} }
        public Klava NumFive{get{this.VK_NumFive.Down();this.Sleep();this.VK_NumFive.Up(); return this;} }
        public Klava NumSix{get{this.VK_NumSix.Down();this.Sleep();this.VK_NumSix.Up(); return this;} }
        public Klava NumSeven{get{this.VK_NumSeven.Down();this.Sleep();this.VK_NumSeven.Up(); return this;} }
        public Klava NumEight{get{this.VK_NumEight.Down();this.Sleep();this.VK_NumEight.Up(); return this;} }
        public Klava NumNine{get{this.VK_NumNine.Down();this.Sleep();this.VK_NumNine.Up(); return this;} }
        public Klava NumStar{get{this.VK_NumStar.Down();this.Sleep();this.VK_NumStar.Up(); return this;} }
        public Klava NumPlus{get{this.VK_NumPlus.Down();this.Sleep();this.VK_NumPlus.Up(); return this;} }
        public Klava NumMinus{get{this.VK_NumMinus.Down();this.Sleep();this.VK_NumMinus.Up(); return this;} }
        public Klava NumDot{get{this.VK_NumDot.Down();this.Sleep();this.VK_NumDot.Up(); return this;} }
        public Klava NumSlash{get{this.VK_NumSlash.Down();this.Sleep();this.VK_NumSlash.Up(); return this;} }
        public Klava NUMLOCK{get{this.VK_NUMLOCK.Down();this.Sleep();this.VK_NUMLOCK.Up(); return this;} }
        public Klava SCROLLLOCK{get{this.VK_SCROLLLOCK.Down();this.Sleep();this.VK_SCROLLLOCK.Up(); return this;} }
        public Klava PRINTSCREEN{get{this.VK_PRINTSCREEN.Down();this.Sleep();this.VK_PRINTSCREEN.Up(); return this;} }
        public Klava PeriodComma{get{this.VK_PeriodComma.Down();this.Sleep();this.VK_PeriodComma.Up(); return this;} }
        public Klava Equally{get{this.VK_Equally.Down();this.Sleep();this.VK_Equally.Up(); return this;} }
        public Klava Сomma{get{this.VK_Сomma.Down();this.Sleep();this.VK_Сomma.Up(); return this;} }
        public Klava Minus{get{this.VK_Minus.Down();this.Sleep();this.VK_Minus.Up(); return this;} }
        public Klava Dot{get{this.VK_Dot.Down();this.Sleep();this.VK_Dot.Up(); return this;} }
        public Klava Tilda{get{this.VK_Tilda.Down();this.Sleep();this.VK_Tilda.Up(); return this;} }
        public Klava SquScobOtk{get{this.VK_SquScobOtk.Down();this.Sleep();this.VK_SquScobOtk.Up(); return this;} }
        public Klava ObratSlash{get{this.VK_ObratSlash.Down();this.Sleep();this.VK_ObratSlash.Up(); return this;} }
        public Klava SquScobZak{get{this.VK_SquScobZak.Down();this.Sleep();this.VK_SquScobZak.Up(); return this;} }
        public Klava MouseL{get{this.VK_MouseL.Down();this.Sleep();this.VK_MouseL.Up(); return this;} }
        public Klava MouseR{get{this.VK_MouseR.Down();this.Sleep();this.VK_MouseR.Up(); return this;} }
        public Klava MMouse{get{this.VK_MMouse.Down();this.Sleep();this.VK_MMouse.Up(); return this;} }
    }
}
















